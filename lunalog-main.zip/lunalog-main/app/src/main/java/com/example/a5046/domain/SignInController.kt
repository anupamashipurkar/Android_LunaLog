package com.example.a5046.domain

class SignInController {
}