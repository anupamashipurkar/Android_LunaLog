package com.example.a5046.presentation.util

object Constants {
    const val DIARY_ID_ARG = "diary_id"
}